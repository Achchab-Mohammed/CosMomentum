/* ===========================================================================================================
 *
 * Copyright:Mohammed Achchab, Frankfurt University of Applied Sciences, 2021
 * 
 * Date: 18.04.2021
 *
 * PSoC Design Course 2021: Excercise 2, PWM and Interrupts
 *
 * Description: Turn the servo in 5 different angles gradually by pressing the button.
 *
 * ============================================================================================================
*/

/* library including */
#include "project.h"
#include "stdio.h"

/* variable to select the target comparevalue */
int val=2;
/* array of values between 2000 and 4000 */
int pwm_select[5] = {2000,2500,3000,3500,4000};
/* start from neutral position (1.5ms pulse width) */
uint16 pwmval = 3000;

/* function prototype */
CY_ISR_PROTO(Button_Handler);
CY_ISR_PROTO(PWM_Handler);

int main(void)
{
    
    /* Enable global interrupts. */
    CyGlobalIntEnable; 
    
    /* starts the clock components */
    Clock_PWM_Start();
    Clock_Debouncer_Start();
    /* starts the PWM components */
    PWM_Start();
    /* Sets the comparevalue at neutral position */
    PWM_WriteCompare(pwmval);
    /* set up the interrupts and enable */
    isr_Button_StartEx(Button_Handler);
    isr_PWM_StartEx(PWM_Handler);
    
    /* infinite for loop */
    for(;;){
    
    }
}


int select_PWM_value(){
    /* select the compare value and return it */
    pwmval = pwm_select[val];
    
    return pwmval;
    
}

CY_ISR(Button_Handler){
    /* set the pwmval from the array */
    if(val < 4){
        val++;
        select_PWM_value();
    }else{
        val = 0;
        select_PWM_value();
    }
    
}

CY_ISR(PWM_Handler){
     
static uint16 compval = 3000;
static uint16 step = 10;
   
    /* move the servo smoothly at increments of 10 until 180 degree */
    while (compval < pwmval) {
      
        compval += step;
        PWM_WriteCompare (compval);
        CyDelay(40);
    }
    /* move the servo smoothly at decrements of 10 until 0 degree */
    while (compval > pwmval) {
        compval -= step;
        PWM_WriteCompare (compval);
        CyDelay(40);
        }
    
   /* clear PWM interrupt by reading the status register */
   PWM_ReadStatusRegister();

}


/* [] END OF FILE */
